window.codapPluginConfig = {
  buildNumber: "0060"
}
